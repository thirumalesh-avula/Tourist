package com.comeureka.sprincomeur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprinComeurApplicationTests {

	@Test
	void contextLoads() {
	}

}
