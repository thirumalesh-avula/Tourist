package com.comeureka.sprincomeur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class SprinComeurApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprinComeurApplication.class, args);
	}

}
