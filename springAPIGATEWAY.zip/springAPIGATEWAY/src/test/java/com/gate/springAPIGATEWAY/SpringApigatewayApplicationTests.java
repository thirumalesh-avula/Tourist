package com.gate.springAPIGATEWAY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApigatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
