package com.compr.springcompr;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.compr.springcompr.entity.Tour;
import com.compr.springcompr.repository.TourRepo;



@SpringBootTest
class SpringComprApplicationTests {

	@Autowired
	private TourRepo tourRepo;

	@Test
	public void savetouristtest() {
	   
	   Tour tourist = new Tour();
	   tourist.setFirstName("max");
	   tourist.setLastName("steve");
	   tourist.setAge(23);
	   tourist.setGender("female");
	   tourist.setFromplace("ind");
	   tourist.setNumberofdays("5");
	   
	   tourRepo.save(tourist);
	   assertNotNull(tourRepo.findAll().get(0));
	   
	}

	@Test
	public void  getdataalltest() {
	   List<Tour> listtour = tourRepo.findAll();
	   assertThat(listtour).size().isGreaterThan(0);
	}



}
