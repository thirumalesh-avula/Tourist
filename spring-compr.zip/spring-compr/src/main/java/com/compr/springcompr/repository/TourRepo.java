package com.compr.springcompr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.compr.springcompr.entity.Tour;

public interface TourRepo extends JpaRepository<Tour, Long> {
	
}
