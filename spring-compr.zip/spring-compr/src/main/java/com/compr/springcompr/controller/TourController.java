package com.compr.springcompr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.compr.springcompr.entity.Tour;
import com.compr.springcompr.service.TourService;

@RestController
@RequestMapping("/Tourist")
public class TourController {
	
	@Autowired
	private TourService tourService;
	
	@PostMapping("/addTourist")
	public Tour addTourWithJavaconfig (@RequestBody Tour tour) {
		return tourService.save(tour);
		
	}
	
	@PostMapping("/addlisttourist")
	public List<Tour> addTour(@RequestBody List <Tour> tour){
		return tourService.save(tour);
	}
	
	@GetMapping("/getTourist")
	public List<Tour> getTourWithJavaconfig(){
		return tourService.getTour();
	
	}
	
/*
	@PutMapping("/updateTourist")
	public List<Tour> updateTour(@RequestBody List <Tour> tour){
		return tourService.getTour(tour);
	
	}
	
	@DeleteMapping("/deleteTourist")
	public List<Tour> deleteTour(@RequestBody List <Tour> tour){
		return tourService.getTour(tour);
	
	}
	
	*/
	
	
	

}
