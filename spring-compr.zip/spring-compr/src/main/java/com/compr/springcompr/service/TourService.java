package com.compr.springcompr.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.compr.springcompr.entity.Tour;
import com.compr.springcompr.repository.TourRepo;

@Service
public class TourService {

    @Autowired
    private TourRepo tourRepo;

    public Tour save(Tour tour) {
        return tourRepo.save(tour);
    }

    public List<Tour> save(List<Tour> tour) {
        return tourRepo.saveAll(tour);
    }


    public List<Tour> getTour() {
        return tourRepo.findAll();
    }
/*
    public Tour updateTourist(Tour tourist) {
        Tour existingTourist = tourRepo.findById(tour.gettid());
        existingTourist.setFirstName(tourist.getFirstname());
        existingTourist.setLastName(tourist.getLastname());
        return tourRepo.save(null);
    }
*/
  /*  public String deleteTour(int id) {
        tourRepo.deleteById(id);
        return "Tourist Removed"+id;
    }
    */
}
