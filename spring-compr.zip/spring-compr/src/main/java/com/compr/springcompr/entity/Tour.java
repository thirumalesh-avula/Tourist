package com.compr.springcompr.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Touristsdetails")
public class Tour {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long Id;
	@Column(name="first_name")
	private String firstName;
	@Column(name="last_name")
	private String lastName;
	private String gender;
	private int age;
	@Column(name="from_place")
	private String fromplace;
	@Column(name="number_of_days")
	private String numberofdays;
	
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getFromplace() {
		return fromplace;
	}
	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}
	public String getNumberofdays() {
		return numberofdays;
	}
	public void setNumberofdays(String numberofdays) {
		this.numberofdays = numberofdays;
	}
	
	public Tour(long id, String firstName, String lastName, String gender, int age, String fromplace,
			String numberofdays) {
		super();
		Id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.fromplace = fromplace;
		this.numberofdays = numberofdays;
	}
	

	public Tour() {
		
	}
	
}
